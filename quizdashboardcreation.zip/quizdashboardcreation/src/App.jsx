import React, { useState } from "react";
import "./index.css";

function Header() {
  return (
    <header className="header">
      <h1>Quiz Creator</h1>
      <div className="profile">John Doe</div>
    </header>
  );
}

function Stats() {
  const stats = [
    { label: "Total Quizzes", value: 10 },
    { label: "Questions Added", value: 38 },
    { label: "Views", value: 87 },
    { label: "Passing Rate", value: "76%" },
  ];

  return (
    <section className="stats">
      {stats.map((stat, idx) => (
        <button key={idx} className="stat-button">
          <div className="stat-label">{stat.label}</div>
          <div className="stat-value">{stat.value}</div>
        </button>
      ))}
    </section>
  );
}

function AddQuestionSection({ onAdd }) {
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", "", "", ""]);
  const [correct, setCorrect] = useState(null);

  const handleOptionChange = (value, index) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };

  const addQuestion = () => {
    if (!question || options.some((o) => o === "") || correct === null) {
      alert("Please fill all fields and select the correct answer.");
      return;
    }

    onAdd({
      question,
      options,
      correct,
    });

    // Reset fields
    setQuestion("");
    setOptions(["", "", "", ""]);
    setCorrect(null);
  };

  return (
    <div className="card">
      <h2 className="section-title">Add a Question</h2>

      <input
        className="input"
        placeholder="Enter question"
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
      />

      {options.map((opt, idx) => (
        <div key={idx}>
          <input
            className="input"
            placeholder={`Option ${idx + 1}`}
            value={opt}
            onChange={(e) => handleOptionChange(e.target.value, idx)}
          />
          <label>
            <input
              type="radio"
              name="correct"
              checked={correct === idx}
              onChange={() => setCorrect(idx)}
            />
            Correct
          </label>
        </div>
      ))}

      <button className="btn-primary" onClick={addQuestion}>
        Add Question
      </button>
    </div>
  );
}

function PreviewQuiz({ questions }) {
  return (
    <div className="card">
      <h2 className="section-title">Preview Quiz</h2>

      {questions.length === 0 ? (
        <div className="empty">No questions added yet.</div>
      ) : (
        questions.map((q, idx) => (
          <div key={idx} className="question-block">
            <strong>{idx + 1}. {q.question}</strong>

            <ul className="options">
              {q.options.map((opt, i) => (
                <li
                  key={i}
                  className={i === q.correct ? "correct-answer" : ""}
                >
                  {opt}
                </li>
              ))}
            </ul>
          </div>
        ))
      )}
    </div>
  );
}

export default function App() {
  const [questions, setQuestions] = useState([]);

  const handleAddQuestion = (q) => {
    setQuestions([...questions, q]);
  };

  return (
    <div className="dashboard">
      <Header />
      <Stats />

      <div className="main">
        <AddQuestionSection onAdd={handleAddQuestion} />
        <PreviewQuiz questions={questions} />
      </div>
    </div>
  );
}
